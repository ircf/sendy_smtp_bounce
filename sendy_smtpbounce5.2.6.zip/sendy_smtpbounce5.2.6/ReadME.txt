For Sendy 5.2.3

Sendy Bounce SMTP for each brand.

1. You will have to go into your mysql database and run the mysql code below.
It will create the columns needed for the bounce to work.

ALTER TABLE apps
ADD COLUMN bounce_host VARCHAR(100) NOT NULL AFTER smtp_password,
ADD COLUMN bounce_port VARCHAR(100) NOT NULL AFTER bounce_host,
ADD COLUMN bounce_username VARCHAR(100) NOT NULL AFTER bounce_port,
ADD COLUMN bounce_password VARCHAR(100)NOT NULL AFTER bounce_username;

2. Upload all the files included and overwrite the old files. 
3. Create a bounce email like mail@yourdomain.com.  This will catch all the bounced emails.
4. Create or Edit your brand under smtp fill out the form with your bounce email details.

Create cron to run every 15 minutes
usr/bin/php /path/to/sendy/bounce.php > /dev/null 2>&1




